
		
database 	=bali_db

		~level Akses~
level 1		= admin
level 2		= user 

		~username & password~
Admin
useranme 	= admin@bali
password	= admin2022

User
username	= user@bali
password	= user2022