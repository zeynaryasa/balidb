<?php
$conn = mysqli_connect("localhost", "root", "", "bali_db") or die("gagal");